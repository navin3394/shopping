package com.niit.DAO;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.Model.Category;



@Repository
public interface CategoryDAO {
	
	public boolean saveOrUpdate(Category category);
	
	public boolean update(Category category);
	
	public void delete(String id);
	
	public Category get(String id);
	
	public List<Category> list();
	
	public Category getByName(String name);
	

}