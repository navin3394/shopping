package com.niit.Controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.DAO.UserdetailsDAO;
import com.niit.Model.Userdetails;

@Controller
public class Usercontroller {
	@Autowired(required=true)
	UserdetailsDAO userdetailsDAO;
	
	@Autowired
	Userdetails userdetails;
		@RequestMapping("/Login")
	public ModelAndView login(@RequestParam(value = "username")String username, @RequestParam(value= "password")String password,HttpSession session)
	{
		ModelAndView mv=new ModelAndView();
		String msg;
		userdetails = userdetailsDAO.isValidUser(username, password);

		if(userdetails.getRole().equals("ROLE_USER"))
		{
			mv = new ModelAndView("LoginSuccess");
		}
		else
		{
			if(userdetails.getRole().equals("ROLE_ADMIN"))
			{
				mv = new ModelAndView("AdminHome");
			}
			session.setAttribute("Welcome", userdetails.getUsername());
		
		}
		return mv;
	}
@RequestMapping("/logout")
public ModelAndView logout(HttpServletRequest request,HttpSession session)
{
	ModelAndView mv= new ModelAndView("Home");
	session.invalidate();
	session=request.getSession(true);
	mv.addObject("logoutMessage","You successfully logged out");
	mv.addObject("loggedOut", "true");
	return mv;
}
	

}
