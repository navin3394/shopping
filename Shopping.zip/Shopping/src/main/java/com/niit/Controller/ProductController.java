package com.niit.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.DAO.ProductDAO;
import com.niit.Model.Product;



@Controller
public class ProductController {
	
	
	@Autowired
	private ProductDAO productDAO;
	@Autowired
	private Product product;
	
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public String listProducts(Model model){
		
		model.addAttribute("product",product);
		model.addAttribute("productlist",productDAO.list());
	
		return"product";
	}
	@RequestMapping(value="/products/add",method=RequestMethod.GET)
	public String addProducts(@ModelAttribute("product")Product product){
		
		ModelAndView mv=new ModelAndView();
		if(productDAO.get(product.getId())==null){
			productDAO.save(product);
		}
		else{
			mv.addObject("error msg","the record exists with id" +product.getId());
		}
		//ProductDAO.saveOrupdate(product);
	
			return "product";
		}
	@RequestMapping(value="/product/remove{id}")
	public ModelAndView deleteProducts(@PathVariable("id")Product id){
		boolean flag=productDAO.delete(id);
		ModelAndView mv=new ModelAndView();
		String msg="Successfully done the operation";
		if(flag!=true)
		{
			msg="the operation could not be success";
		}
		mv.addObject("msg",msg);
		
		return mv;
	}
	@RequestMapping(value="/product/edit{id}")
	public void editProducts(@PathVariable("id") String id, Model model){
		if(productDAO.get(id)!=null){
			productDAO.update(product);
			model.addAttribute("mssg","Successfully updated");
		}
		else{
			model.addAttribute("error msg","couldnot update the record");
		}
		
	}
}


