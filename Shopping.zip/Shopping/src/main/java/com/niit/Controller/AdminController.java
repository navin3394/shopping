package com.niit.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.DAO.CategoryDAO;
import com.niit.DAO.ProductDAO;
import com.niit.DAO.SupplierDAO;
import com.niit.Model.Category;
import com.niit.Model.Product;
import com.niit.Model.Supplier;

@Controller
public class AdminController {
	
	/*@Autowired
	private ProductDAO productDAO;
	@Autowired 
	private Product product;
*/
	@Autowired
	private Supplier supplier;
	@Autowired
	private SupplierDAO supplierDAO;
	@Autowired
	private Category category;
	
	@Autowired
	private CategoryDAO categoryDAO;
	@RequestMapping("/AdminHome")
	public ModelAndView AdminHome()
	{
		ModelAndView mv = new ModelAndView("Home");
		mv.addObject("isAdminClickedHome", "true");
		return mv;
	}
	
	
	
   /*@RequestMapping(value="/manageProduct",method=RequestMethod.GET)
   public ModelAndView Product(){
	   ModelAndView mv=new ModelAndView("NewFile");
	   mv.addObject("product",product);
	   mv.addObject("isAdminClickedProduct","true");
	   mv.addObject("productlist", productDAO.list());
	   return mv;
   }*/
   @RequestMapping(value="/manageSupplier",method=RequestMethod.GET)
   public ModelAndView Supplier(){
	   ModelAndView mv=new ModelAndView("AdminSupplier");
	   mv.addObject("supplier",supplier);
	   mv.addObject("isAdminClickedSupplier","true");
	   mv.addObject("supplierlist",supplierDAO.list());
	   return mv;
   }
   @RequestMapping(value="/manageCategory",method=RequestMethod.GET)
	public ModelAndView categories()
	{
		ModelAndView mv = new ModelAndView("AdminCategory");
		mv.addObject("category", category);
		mv.addObject("isAdminClickedCategories","true");
		mv.addObject("categoryList", categoryDAO.list());
		return mv;
	}
	
 
}
